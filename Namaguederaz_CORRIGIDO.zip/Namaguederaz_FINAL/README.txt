NAMAGUEDERAZ — pacote corrigido

Correções desta versão:
- caminhos locais preparados para Android/Capacitor;
- API do YouTube carregada explicitamente;
- erro de inicialização não deixa o usuário sem mensagem;
- o build do Android cria a pasta android automaticamente se ela não existir.

IMPORTANTE:
Este ZIP é o código do projeto. Ele ainda precisa ser colocado no repositório e compilado pelo GitHub Actions para gerar o APK.
