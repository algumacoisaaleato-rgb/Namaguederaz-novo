const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const crypto = require("crypto");

// Camada de segurança: o app não injeta anúncios, scripts remotos arbitrários ou executáveis.
// Limites simples também reduzem abuso do servidor durante o protótipo.
const MAX_CHAT = 500;
const MAX_ROOMS = 500;
const RATE_WINDOW_MS = 10000;
const RATE_MAX = 30;
const rates = new WeakMap();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({server});
app.disable("x-powered-by");
app.use((req,res,next)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("X-Frame-Options","SAMEORIGIN");
  res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy","camera=(), geolocation=(), payment=()");
  next();
});
app.use(express.static("public"));

const rooms = new Map();

function id(){ return crypto.randomBytes(4).toString("hex").toUpperCase(); }
function broadcast(room, message){
  for(const client of room.clients){
    if(client.readyState === WebSocket.OPEN) client.send(JSON.stringify(message));
  }
}
function snapshot(room){
  return {type:"room_state", roomId:room.id, host:room.host,
    media:room.media, public:room.public, participants:[...room.users.values()].map(u=>({id:u.id,name:u.name,mic:u.mic}))};
}

wss.on("connection", ws=>{
  ws.on("message", raw=>{
    const now=Date.now();
    const r=rates.get(ws)||{start:now,count:0};
    if(now-r.start>RATE_WINDOW_MS){r.start=now;r.count=0}
    r.count++; rates.set(ws,r);
    if(r.count>RATE_MAX){ ws.send(JSON.stringify({type:"error",message:"Muitas ações em pouco tempo. Aguarde alguns segundos."})); return; }
    let m; try {m=JSON.parse(raw)} catch {return}
    if(m.type==="create"){
      if(rooms.size>=MAX_ROOMS){ws.send(JSON.stringify({type:"error",message:"Servidor temporariamente cheio."}));return}
      const rid=id(), userId=id();
      const room={id:rid,host:userId,name:String(m.roomName||"Sala").slice(0,80),public:!!m.publicRoom,clients:new Set(),users:new Map(),
        media:{platform:m.platform||null,url:m.url||"",title:m.title||"",position:0,playing:false},public:!!m.publicRoom};
      rooms.set(rid,room); ws.room=room; ws.userId=userId;
      room.clients.add(ws); room.users.set(userId,{id:userId,name:m.name||"Você",mic:false});
      ws.send(JSON.stringify({type:"created",roomId:rid,userId}));
      ws.send(JSON.stringify(snapshot(room))); return;
    }
    if(m.type==="list_public"){
      const list=[...rooms.values()].filter(r=>r.public).slice(0,30).map(r=>({id:r.id,name:r.name,media:r.media.title})); ws.send(JSON.stringify({type:"public_rooms",rooms:list})); return;
    }
    if(m.type==="join"){
      const room=rooms.get(String(m.roomId||"").toUpperCase()); if(!room){ws.send(JSON.stringify({type:"error",message:"Sala não encontrada"}));return}
      ws.room=room; ws.userId=id(); room.clients.add(ws); room.users.set(ws.userId,{id:ws.userId,name:m.name||"Convidado",mic:false});
      ws.send(JSON.stringify({type:"joined",roomId:room.id,userId:ws.userId}));
      broadcast(room,snapshot(room)); return;
    }
    const room=ws.room; if(!room)return;
    if(m.type==="set_media" && ws.userId===room.host){
      room.media={...room.media,platform:m.platform||null,url:m.url||"",title:m.title||"",position:Number(m.position)||0,playing:false};
      broadcast(room,snapshot(room)); return;
    }
    if(m.type==="sync"){
      room.media.position=Math.max(0,Number(m.position)||0); room.media.playing=!!m.playing;
      broadcast(room,{type:"sync",position:room.media.position,playing:room.media.playing,by:ws.userId}); return;
    }
    if(m.type==="mic"){
      const u=room.users.get(ws.userId); if(u){u.mic=!!m.enabled;broadcast(room,snapshot(room));} return;
    }
    if(m.type==="signal"){
      const target=room.clients && [...room.clients].find(c=>c.userId===m.to);
      if(target && target.readyState===WebSocket.OPEN){
        target.send(JSON.stringify({type:"signal",from:ws.userId,signal:m.signal}));
      }
      return;
    }
    if(m.type==="chat"){
      broadcast(room,{type:"chat",name:room.users.get(ws.userId)?.name||"Usuário",text:String(m.text||"").slice(0,500)}); return;
    }
  });
  ws.on("close",()=>{
    const r=ws.room;if(!r)return;
    r.clients.delete(ws);r.users.delete(ws.userId);
    if(r.users.size===0)rooms.delete(r.id); else broadcast(r,snapshot(r));
  });
});

app.get("/health",(req,res)=>res.json({ok:true,rooms:rooms.size}));
server.listen(process.env.PORT||3000,()=>console.log("Namaguederaz em http://localhost:"+ (process.env.PORT||3000)));
