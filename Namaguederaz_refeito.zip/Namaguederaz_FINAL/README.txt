NAMAGUEDERAZ — PACOTE FINAL DO PROTÓTIPO

Versão: 1.0 Final (protótipo funcional)

Inclui: salas, YouTube, navegador interno, chat, voz WebRTC, sincronização, recomendações opcionais, próximo episódio, modo seguro e PWA.

SEGURANÇA:
- O Namaguederaz não insere anúncios próprios.
- O app não baixa nem executa arquivos recebidos pelo chat.
- Recomendações +18 são filtradas/bloqueadas no protótipo.
- Conteúdo de sites externos continua sujeito às regras, anúncios e proteções do próprio site.

IMPORTANTE:
Este pacote é um protótipo web/PWA e não é uma APK/IPA de produção. Para publicar nas lojas ainda são necessários empacotamento nativo, HTTPS/produção, autenticação, domínio/infraestrutura e revisão das políticas de cada serviço integrado.

EXECUÇÃO:
1. Instale Node.js 18+.
2. Rode: npm install
3. Rode: npm start
4. Abra o endereço local mostrado no terminal.
